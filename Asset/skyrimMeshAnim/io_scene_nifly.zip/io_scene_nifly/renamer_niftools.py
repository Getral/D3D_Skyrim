#bl_info = {
#    "name": "Rename bones and vertex groups",
#    "description": "Renames a armature's bones from PyNifly convention to NifTools; also does vertex groups of associated objects",
#    "blender": (3, 0, 0),
#    "author": "Bad Dog",
#    "category": "Object",
#}

import bpy
from niflytools import skyrimDict




