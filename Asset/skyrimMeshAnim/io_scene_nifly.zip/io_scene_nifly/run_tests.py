RUN_TESTS = True
TEST_ALL = False
TEST_EXPORT = False
TEST_IMPORT_ARMATURE = False
TEST_EXPORT_WEIGHTS = True

filename = r"D:\OneDrive\Dev\PyNifly\PyNifly\__init__.py"
exec(compile(open(filename).read(), filename, 'exec'))
